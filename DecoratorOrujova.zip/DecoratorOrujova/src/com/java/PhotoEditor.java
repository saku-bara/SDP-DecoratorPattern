package com.java;

public interface PhotoEditor {
    String editPhoto();
    Integer NumOfChanges();
}
